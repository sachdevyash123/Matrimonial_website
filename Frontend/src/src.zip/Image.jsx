import React from "react"
// import Img from "./img1.jpg"
// import Img from "./img2.jpg"
import Img from "./img5.jpg"
const Image=()=>{
    return(
        <>
        <div className="row mt-5 opacity-4">
        <img class="img-responsive col-12" src={Img} alt="Chania" height="540px"></img>
        </div>
        
        </>
    )
}
export default Image