import React from "react";
import { Link } from "react-router-dom";
const Login = () => {
  return (
    <>
      <div class="vh-100 d-flex justify-content-center align-items-center mt-2">
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8 col-lg-6">
              <div class="card bg-dark text-light">
                <div class="card-body p-5">
                  <form class="mb-3 mt-md-4">
                    <h2 class="fw-bold mb-2 text-uppercase text-center ">
                      Login Now!
                    </h2>

                    <div class="mb-3">
                      <label for="email" class="form-label ">
                        Email address
                      </label>
                      <input
                        type="email"
                        class="form-control"
                        id="email"
                        placeholder="name@example.com"
                      />
                    </div>
                    <div class="mb-3">
                      <label for="password" class="form-label ">
                        Password
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        id="password"
                        placeholder="*******"
                      />
                    </div>
                    {/* <p class="small">
                      <a class="text-primary" href="forget-password.html">
                        Forgot password?
                      </a>
                    </p> */}
                    <div class="d-grid">
                      <button class="btn btn-outline-light" type="submit">
                        Login
                      </button>
                    </div>
                  </form>
                  <div>
                    <p class="mb-0  text-center">
                      Don't have an account?
                      <Link to="/Signup" class="text-light fw-bold">
                        Sign Up
                      </Link>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Login
