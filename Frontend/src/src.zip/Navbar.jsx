import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Avtar from "./avtar.png"
import "./Nstyle.css"
// import Image from "./Image";
// import About1 from "./About1";
const Navbar = () => {
  return (
    <>
      <nav
        className="navbar navbar-expand-sm fixed-top  "
        style={{ backgroundColor: "#8bc3c4",color:"black" }}
      >
        <div class="container-fluid">
          
          <button
            className="navbar-toggler ml-auto"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapsibleNavbar"
            
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse text-info"
            id="collapsibleNavbar"
          >
            <ul className="navbar-nav  me-auto p-1">
              <li className="nav-item">
                <Link className="nav-link  fs-5" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link  fs-5" to="/About">
                  About
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link  fs-5" to="/Contact">
                  ContactUs
                </Link>
              </li>
              <li className="nav-item">
                
              </li>
            </ul>
            <button type="button" className="btn    d-flex fs-5" >
            <Link className="nav-link login fs-5" to="/Login">
                  Login
                </Link>
            </button>
          </div>
        </div>
      </nav>
    </>
  );
};
export default Navbar;
