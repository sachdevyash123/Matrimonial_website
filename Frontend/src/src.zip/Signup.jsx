import React from "react";
import {Link} from "react-router-dom"

function Signup() {
  return (
    <>
      <div className="vh-70 d-flex justify-content-center align-items-center mt-5 ">
        <div className="container ">
          <div className="row d-flex justify-content-center">
            <div className="col-12 col-md-8 col-lg-6 ">
              <div className="card bg-white bg-dark">
                <div className="card-body p-5 bg-dark text-white">
                  <form className="mb-3 mt-md-4 " action="reg2.html">
                    <h2 className="fw-bold mb-2 text-uppercase text-center ">
                      Register Now!
                    </h2>

                    <div className="mb-3">
                      <label for="fname" className="form-label ">
                        Firstname
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="fname"
                        placeholder="Firstname "
                      />
                    </div>
                    <div className="mb-3">
                      <label for="mname" className="form-label ">
                        Middlename
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="mname"
                        placeholder="Fathername "
                      />
                    </div>
                    <div className="mb-3">
                      <label for="lname" className="form-label ">
                        Lastname
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="mname"
                        placeholder="Caste "
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label d-flex">Gender</label>
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="radio"
                          name="gender"
                          id="male"
                          value="male"
                        />
                        <label className="form-check-label" for="male">
                          Male
                        </label>
                      </div>
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="radio"
                          name="gender"
                          id="female"
                          value="female"
                        />
                        <label className="form-check-label" for="female">
                          Female
                        </label>
                      </div>
                    </div>
                    <div className="mb-3">
                      <label for="number" className="form-label ">
                        Mobile Number
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="number"
                        placeholder="1234567895"
                      />
                    </div>
                    <div className="mb-3">
                      <label for="password" className="form-label ">
                        Password
                      </label>
                      <input
                        type="password"
                        className="form-control"
                        id="password"
                        placeholder="*******"
                      />
                    </div>

                    <div class="mb-3">
                      <label for="email" class="form-label ">
                        Email
                      </label>
                      <input
                        type="email"
                        class="form-control"
                        id="email"
                        placeholder="abc@gmail.com "
                      />
                    </div>
                    <div class="mb-3">
                      <label for="age" class="form-label ">
                        Age
                      </label>
                      <input
                        type="number"
                        class="form-control"
                        id="age"
                        placeholder="20-80 "
                      />
                    </div>
                    <div class="mb-3">
                      <label for="height" class="form-label">
                        Height
                      </label>
                      
                      <select class="form-select" id="height" name="height">
                        <option value="4'6">4'6"</option>
                        <option value="4'7">4'7"</option>
                        <option value="4'8">4'8"</option>
                        <option value="4'9">4'9"</option>
                        <option value="4'9">5'0"</option>
                        <option value="4'9">5'1"</option>
                        <option value="4'9">5'2"</option>
                        <option value="4'9">5'3"</option>
                        <option value="4'9">5'4"</option>
                        <option value="4'9">5'5"</option>
                        <option value="4'9">5'6"</option>
                        <option value="4'9">5'7"</option>
                        <option value="4'9">5'8"</option>
                        <option value="4'9">5'9"</option>
                        <option value="4'9">6'0"</option>
                        <option value="4'9">6'1"</option>
                        <option value="4'9">6'2"</option>
                        <option value="4'9">6'3"</option>
                        <option value="4'9">6'4"</option>
                        <option value="4'9">6'5"</option>
                        <option value="4'9">6'6"</option>
                        <option value="4'9">6'7"</option>
                        <option value="4'9">6'8"</option>
                        <option value="4'9">6'9"</option>
                        <option value="4'9">7'0"</option>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label class="form-label d-flex">Maritial Status</label>
                      
                      <div class="form-check form-check-inline">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="status"
                          id="single"
                          value="single"
                        />
                        <label class="form-check-label" for="single">
                          Single
                        </label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="status"
                          id="divorced"
                          value="divorced"
                        />
                        <label class="form-check-label" for="divorced">
                          Divorced
                        </label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="status"
                          id="married"
                          value="married"
                        />
                        <label class="form-check-label" for="married">
                          Married
                        </label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="status"
                          id="widowed"
                          value="widowed"
                        />
                        <label class="form-check-label" for="widowed">
                          Widowed
                        </label>
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="plocation" class="form-label ">
                        Permanant Location
                      </label>
                      <input
                        type="number"
                        class="form-control"
                        id="plocation"
                        placeholder="e.g. Ahmedabad "
                      />
                    </div>
                    <div class="mb-3">
                      <label for="prlocation" class="form-label ">
                        Present Location
                      </label>
                      <input
                        type="number"
                        class="form-control"
                        id="prlocation"
                        placeholder="e.g. Ahmedabad "
                      />
                    </div>

                    <div class="mb-3">
                      <label class="form-label mx-auto d-flex">Physical Disability</label>
                      <div class="form-check form-check-inline">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="Disability"
                          id="yes"
                          value="yes"
                        />
                        <label class="form-check-label" for="yes">
                          Yes
                        </label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input
                          class="form-check-input"
                          type="radio"
                          name="Disability"
                          id="no"
                          value="no"
                        />
                        <label class="form-check-label" for="no">
                          No
                        </label>
                      </div>
                    </div>
                    <div className="d-grid">
                      {/* <button className="btn btn-outline-danger" > */}
                        <Link to="/">
                            Next
                        </Link>
                      {/* </button> */}
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Signup;
