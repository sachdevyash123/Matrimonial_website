import Image from "./Image";
import React from "react";
import "./style.css";
const Home = () => {
  return (
    <>
      <Image />
      <section class="light-bg success-section mt-3 section">
        <div class="container">
          <div class="row">
            <div class="col-xs-12">
              <h1 class="text-uppercase page-title text-center fs-2">
                Success Stories
              </h1>
              <div class="row success-text-wrapper">
                <div class="col-md-12 col-sm-12 mt-2">
                  <p className="text-center">
                    From 2010, We have success of more than 2000 matches. They
                    were from caste like Brahmin, Vania, Patel, Jain and many
                    more in India and across the world.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="container mt-5">
            <div className="container mt-5">
              <div className="row box-container">
                <div className="col-lg-4 col-md-4 mb-4">
                  <div className="d-flex flex-column h-100 box">
                    <div className="box-number fs-2">155</div>
                    <div className="box-text text-center fs-5">
                    New Profiles in last 30 Days
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 col-md-5 mb-4">
                  <div className="d-flex flex-column h-100 box">
                    <div className="box-number fs-2">498</div>
                    <div className="box-text text-center fs-5">
                    Got engaged through us
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 col-md-6 mb-4">
                  <div className="d-flex flex-column h-100 box">
                    <div className="box-number fs-2">500</div>
                    <div className="box-text text-center fs-5">
                    Active Profiles
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container-fluid mt-3 section">
        <h1 className="fs-2 text-center">Premium Plans</h1>
        <div className="row premium">
          <div className="col-lg-3 col-md-6 mt-3">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title text-center">Special title treatment</h5>
                <p className="card-text">✔ US $33 Membership Per Month</p>
                <p>✔ Send Customized interests</p>
                <p>✔ See Contact Phone Nos</p>
                <p>✔ Priority Customer Support</p>
                <p>✖ Profile Boost</p>
                <a   className="btn btn-outline-primary">
                  Buy Now
                </a>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-6  mt-3">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title text-center">Special title treatment</h5>
                <p className="card-text">✔ US $33 Membership Per Month</p>
                <p>✔ Send Customized interests</p>
                <p>✔ See Contact Phone Nos</p>
                <p>✔ Priority Customer Support</p>
                <p>✔ Profile Boost</p>
                <a  className="btn btn-outline-primary align-item-center">
                  Buy 
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Home;
