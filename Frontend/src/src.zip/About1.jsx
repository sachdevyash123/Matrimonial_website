import About from "./About";
import React from "react";

const About1=()=>{
    return(
        <About/>
    );
}
export default About1;