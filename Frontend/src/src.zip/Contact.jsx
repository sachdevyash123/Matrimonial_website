import React from "react";
import "./style.css"

const Contact = () => {

    return(
        <>
            {/* <div className="container mx-auto contact ">
            <p className="text-center t2 mt-5"><strong>CONTACT US</strong></p><br/>
            <div >
                <div className=" first text-white text-center" style={{ backgroundColor: "rgba(122, 50, 29, 1)" ,borderRadius:"10px"}}>
                    <div className="t1 ">
                        SWAYAMWAR COMPUTERISED MARRIAGE BUREAU
                    </div>
                   
                </div>
                <div className="container-fluid mt-5 text-center fs-3 " style={{borderRadius:"15px",backgroundImage: "linear-gradient(to right, #02AABD, #00CDAC)"}}>
                    <p className="t3"> 
                        "Basera" Bunglow,
                        Spring Valley, First Gate, B/h. 
                        Karnavati Club, Mumatpura Road, 
                        Ahmedabad - 380058.</p>
                    <p className="t3">1234567891</p>
                    <p className="t3">swyamwar4u@yahoo.com</p>
                    <p className="t3"> Monday-Wednesday-Friday
                        (3:00 p.m. to 7:00 p.m.)
                        (Remain close on all public holidays)</p>
                    <p className="t3"><strong>London office (For UK and Europe)</strong> 
                        Ashini Trivedi
                        Email - ashinitrivedi@me.com
                        Phone - +44 7545 320350
                        Contact Time - 9 AM to 5 PM
                        ( London Time ). Mon to Fri</p>
                </div>
            </div>
        
        </div> */}

<div class="container mt-5">
    <div class="row">
      <div class="col-md-6 mt-4 ">
        <h2>Contact Us</h2>
        <p>If you have any questions or inquiries, feel free to reach out to us. Our team will be happy to assist you.</p>
        <form>
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" placeholder="Your Name"/>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" placeholder="Your Email"/>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea class="form-control" id="message" rows="5" placeholder="Your Message"></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
      <div class="col-md-6 mt-4">
      <h2>Address</h2>
        <p><strong>MatrimonialSite</strong></p>
        <p>123 Main Street</p>
        <p>City, Country</p>
        <h2>Contact Information</h2>
        <p>Email: info@matrimonialsitewebsite.com</p>
        <p>Phone: +123 456 7890</p>
      </div>
    </div>
  </div>
        </>
    );
}
export default Contact;