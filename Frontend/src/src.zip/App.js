import React from "react";
import Navbar from "./Navbar";
import Login from "./Login";
import Contact from "./Contact"
// import Nav from "./Nav";
import { Routes, Route } from "react-router-dom";
import About1 from "./About1";
import Home from "./Home";
import Signup from "./Signup";
import Footer from "./Footer";
function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" Component={Home} />
        {/* <Route path="/H" Component={Home} />/ */}
        <Route path="About" Component={About1} />
        <Route path="Contact" Component={Contact} />
        <Route path="Login" Component={Login} />
        <Route path="Signup" Component={Signup} />
      </Routes>
      <Footer/>
    </div>
  );
}

export default App;
